export const commentArray = [
    { key: 'like', value: '🥰', text: '(*´∀`)~♥', description: '再花写得好！喜欢(*´∀`)~♥' },
    { key: 'dislike', value: '😶', text: '(눈‸눈)', description: '再花写得不好！不喜欢(눈‸눈)' },
    { key: 'worship', value: '😍', text: 'ଘ(੭ˊ꒳​ˋ)੭✧', description: '再花写得太好咧！崇拜ଘ(੭ˊ꒳​ˋ)੭✧' },
    { key: 'angry', value: '😡', text: 'ヽ(#`Д´)ﾉ', description: '看完感觉超生气ヽ(#`Д´)ﾉ' },
    { key: 'melon', value: '🍉', text: '(〃∀〃)', description: '没什么事儿，吃个瓜(〃∀〃)' },
    { key: 'nospeak', value: '🤐', text: '(｡ŏ_ŏ)', description: '不知道说什么(｡ŏ_ŏ)' },
]