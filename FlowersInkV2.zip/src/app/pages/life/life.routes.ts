import { Routes } from '@angular/router';
import { HeartComponent } from './heart/heart.component';

export const LIFE_ROUTES: Routes = [
  { path: 'heart', component: HeartComponent },
];
