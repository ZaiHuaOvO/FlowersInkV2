import { Routes } from '@angular/router';
import { LinkComponent } from './link.component';

export const LINK_ROUTES: Routes = [{ path: '', component: LinkComponent }];
