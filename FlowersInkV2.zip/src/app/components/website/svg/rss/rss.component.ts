import { Component } from '@angular/core';

@Component({
  selector: 'flower-rss',
  standalone: true,
  imports: [],
  templateUrl: './rss.component.html',
  styleUrl: './rss.component.css'
})
export class RssComponent {

}
