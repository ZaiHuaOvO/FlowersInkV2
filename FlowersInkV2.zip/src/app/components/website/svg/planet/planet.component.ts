import { Component } from '@angular/core';

@Component({
  selector: 'flower-planet',
  standalone: true,
  imports: [],
  templateUrl: './planet.component.html',
  styleUrl: './planet.component.css'
})
export class PlanetComponent {

}
